#pragma once

#include <list>

#include <jtl/option.hpp>

#include <jtl/result.hpp>
#include <jank/read/lex.hpp>
#include <jank/runtime/object.hpp>
#include <jank/runtime/var.hpp>

/* TODO: Rename file to processor. */
namespace jank::read::parse
{
  struct char_parse_error
  {
    jtl::immutable_string error;
  };

  jtl::result<jtl::immutable_string, char_parse_error>
  parse_character_in_base(jtl::immutable_string const &char_literal, int const base);

  jtl::option<char> get_char_from_literal(jtl::immutable_string const &s);

  struct object_source_info
  {
    bool operator==(object_source_info const &rhs) const;
    bool operator!=(object_source_info const &rhs) const;

    runtime::object_ref ptr{};
    lex::token start, end;
  };

  struct processor
  {
    using object_result = jtl::result<jtl::option<object_source_info>, error_ref>;

    struct shorthand_function_details
    {
      jtl::option<u8> max_fixed_arity{};
      bool variadic{};
      source source;
    };

    struct iterator
    {
      using iterator_category = std::input_iterator_tag;
      using difference_type = std::ptrdiff_t;
      using value_type = object_result;
      using pointer = value_type *;
      using reference = value_type &;

      value_type operator*() const;
      pointer operator->();
      iterator &operator++();
      bool operator!=(iterator const &rhs) const;
      bool operator==(iterator const &rhs) const;

      jtl::option<value_type> latest;
      jtl::ref<processor> p;
    };

    processor(lex::processor::iterator const &b, lex::processor::iterator const &e);

    object_result next();
    object_result parse_list();
    object_result parse_vector();
    object_result parse_map();
    object_result parse_quote();
    object_result parse_character();
    object_result parse_meta_hint();
    object_result parse_reader_macro();
    object_result parse_reader_macro_set();
    object_result parse_reader_macro_fn();
    object_result parse_reader_macro_var_quote();
    object_result parse_reader_macro_symbolic_values();
    object_result parse_regex();
    object_result parse_tagged_uuid();
    object_result parse_tagged_inst();
    object_result parse_tagged_cpp();
    object_result parse_reader_macro_tagged();
    object_result parse_reader_macro_comment();
    object_result parse_reader_macro_conditional(bool splice);
    object_result parse_syntax_quote();
    object_result parse_unquote(bool splice);
    object_result parse_deref();
    object_result parse_symbol();
    object_result parse_nil();
    object_result parse_boolean();
    object_result parse_keyword();
    object_result parse_integer();
    object_result parse_ratio();
    object_result parse_big_integer();
    object_result parse_big_decimal();
    object_result parse_real();
    object_result parse_string();
    object_result parse_escaped_string();

    iterator begin();
    iterator end();

  private:
    jtl::result<runtime::object_ref, error_ref> syntax_quote(runtime::object_ref form);
    jtl::result<runtime::object_ref, error_ref> syntax_quote_expand_seq(runtime::object_ref seq);
    jtl::result<runtime::object_ref, error_ref> syntax_quote_expand_set(runtime::object_ref seq);
    static jtl::result<runtime::object_ref, error_ref>
    syntax_quote_flatten_map(runtime::object_ref seq);
    static bool syntax_quote_is_unquote(runtime::object_ref form, bool splice);

  public:
    lex::processor::iterator token_current, token_end;
    jtl::option<lex::token_kind> expected_closer;
    /* Splicing, in reader conditionals, is not allowed at the top level. When we're parsing
     * some other form, such as a list, we'll bind this var to true. */
    runtime::var_ref splicing_allowed_var;
    /* When we've spliced some forms, we'll put them into this list. Before reading the next
     * token, we should check this list to see if there's already a form we should pull out.
     * This is needed because parse iteration works one form at a time and splicing potentially
     * turns one form into many. */
    std::list<runtime::object_ref> pending_forms;
    lex::token latest_token;
    jtl::option<shorthand_function_details> shorthand;
    /* Whether or not the next form is considered quoted. */
    bool quoted{};
    /* Whether or not the next form is considered syntax-quoted. */
    bool syntax_quoted{};
  };
}
