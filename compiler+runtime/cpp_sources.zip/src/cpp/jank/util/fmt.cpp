#include <jank/util/fmt.hpp>

namespace jank::util
{
  jtl::immutable_string format(char const * const fmt)
  {
    if(jtl::immutable_string_view{ fmt }.contains("{}"))
    {
      throw std::runtime_error{ "Format string has extra {} with no matching argument" };
    }

    jtl::string_builder sb;
    sb(fmt);
    return sb.release();
  }

  void format_to(jtl::string_builder &sb, char const * const fmt)
  {
    if(jtl::immutable_string_view{ fmt }.contains("{}"))
    {
      throw std::runtime_error{ "Format string has extra {} with no matching argument" };
    }

    sb(fmt);
  }
}
